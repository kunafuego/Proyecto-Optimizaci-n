# Proyecto-Optimización
Proyecto del Grupo 13 del curso ICS1113 (Optimización)

En la carpeta /datos se pueden encontrar dos archivos. Primero uno con terminación .ipynb en el cual 
hay una explicación de cada parte de los parámetros mezclado con código python que crea valores aleatorios para estos parámetros.
Luego, hay un archivo .py con el mismo contenido que el jupyter. Este archivo es el que se importa desde main.py para hacer uso 
de los datos por parte del modelo